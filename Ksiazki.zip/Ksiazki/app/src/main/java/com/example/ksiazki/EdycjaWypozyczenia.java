package com.example.ksiazki;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class EdycjaWypozyczenia extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edycja_wypozyczenia);
       //pobranie przesłanych danych
        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        String tytuł = intent.getStringExtra("tytuł");
        String dane = intent.getStringExtra("dane");
        String data = intent.getStringExtra("data");

        //inicjacja pól z widoku
        TextView tytuł_widok = (TextView)findViewById(R.id.wypozyczenie_edycja_tytul);
        EditText dane_widok = (EditText)findViewById(R.id.wypozyczenie_edycja_dane);
        EditText data_widok = (EditText) findViewById(R.id.wypozyczenie_edycja_data);
        Button zapisz = (Button) findViewById(R.id.wypozyczenie_edycja_zapisz);

        //przypisanie pobranych danych do odpowiednich pól
        if (id != null)
        {
            tytuł_widok.setText(tytuł);
            dane_widok.setText(dane);
            data_widok.setText(data);
        }
       else tytuł_widok.setText("co jest");

        //pobranie danych z uzupełnionych pól


        zapisz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LocalDate  dateNow =  LocalDate.now();
                String podaj_dane = dane_widok.getText().toString();
                String podaj_date = data_widok.getText().toString();
                String error ="";

                if(TextUtils.isEmpty(podaj_dane))
                {
                    error += "PODAJ DANE OSOBY! \n";

                }
                if(TextUtils.isEmpty(podaj_date))
                {
                    error +="PODAJ POPRAWNA DATA \n";
                }
                else
                {
                    try {

                        LocalDate sprawdz = LocalDate.parse(podaj_date);
                        if(dateNow.isBefore(sprawdz))
                        {
                            error += "Data z przyszlosci";
                        }
                    } catch (DateTimeParseException e) {
                        error += "Zły format daty";
                    }
                }
                if(TextUtils.isEmpty(error))
                {

                    DBHelper bazadanych = new DBHelper(EdycjaWypozyczenia.this);
                    bazadanych.Edytuj_wypozyczenie(id,podaj_dane,podaj_date);
                    Intent powrot = new Intent(EdycjaWypozyczenia.this, wypozyczone.class);
                    startActivity(powrot);
                }

                else
                {
                    ((TextView)findViewById(R.id.wypozyczenie_edycja_error)).setText(error);
                }
            }

        });






    }
}

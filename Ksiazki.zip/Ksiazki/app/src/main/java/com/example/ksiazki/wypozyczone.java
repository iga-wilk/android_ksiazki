package com.example.ksiazki;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.view.ViewGroup.LayoutParams;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class wypozyczone extends  AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wypozyczone);

        DBHelper bazadanych = new DBHelper(wypozyczone.this);
        Cursor dane = bazadanych.wyswietl_wypozyczone();

        Integer zmienna_pomocnicza = -1;
        String id_list[]= new String[1000];
        String dane_list[] = new String[1000] ;
        String autor_list[]= new String[1000];
        String tytulu_list[]= new String[1000];
        String daty_list[] = new String[1000];
        Integer ilosc = 0;
        ListView Listaksiazek = (ListView)findViewById(R.id.lista2);
        while(dane.moveToNext())
        {
            zmienna_pomocnicza = 1;
   //wypozyczenie_id, id_ksiazka, tytul, autor, nr_strony, dane, Data_wypozyczenia
            autor_list[ilosc] = dane.getString(3);
            dane_list[ilosc] = dane.getString(5);
            id_list[ilosc] = dane.getString(0);
            tytulu_list[ilosc] = dane.getString(2);
            daty_list[ilosc] = dane.getString(6);
            ilosc++;
        }
        if(zmienna_pomocnicza == 1)
        {

            ((TextView)findViewById(R.id.wypozyczone_id)).setText("ID");
            ((TextView)findViewById(R.id.wypozyczone_tytul)).setText("tytul");
            ((TextView)findViewById(R.id.wypozyczone_autor)).setText("autor");
            ((TextView)findViewById(R.id.wypozyczone_dane)).setText("dane");
            ((TextView)findViewById(R.id.wypozyczone_data)).setText("data");
//(Context applicationContext, String[] id_wypozyczenia, String[] tytuly_ksiazkek,String[] autor, String[] dane, String[] data)
            AdapterWypozyczen customadapter = new AdapterWypozyczen(getApplicationContext(), id_list, tytulu_list,autor_list,dane_list,daty_list);
            Listaksiazek.setAdapter(customadapter);
        }
        else
        {
            String tytuł = ((TextView) findViewById(R.id.tytul_wypozyczone)).getText().toString();
            tytuł += " \nBRAK POZYCJI KSIĄŻKOWYCH";
            ((TextView) findViewById(R.id.tytul_wypozyczone)).setText(tytuł);
        }


        Listaksiazek.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String zmienne[] = {"edytuj", "usun wypożyczenie"};
                new AlertDialog.Builder(wypozyczone.this)
                        .setTitle("Wybierz opcję").setItems(zmienne,new DialogInterface.OnClickListener() {
                     public void onClick(DialogInterface dialog, int which) {
                        switch(which){
                         case 0: Intent edycja = new Intent(wypozyczone.this, EdycjaWypozyczenia.class);
                                edycja.putExtra("id",id_list[position]);
                                edycja.putExtra("tytuł",tytulu_list[position]);
                                edycja.putExtra("dane",dane_list[position]);
                                edycja.putExtra("data",daty_list[position]);
                                startActivity(edycja);break;
                         case 1: DBHelper bazadanych = new DBHelper(wypozyczone.this);
                                 bazadanych.usun_wypozyczenie(id_list[position]);
                                 Intent odswiezenie = new Intent(wypozyczone.this, wypozyczone.class);
                               startActivity(odswiezenie); break;

                         default: Toast.makeText(wypozyczone.this,"WYBRALES inne", Toast.LENGTH_LONG);
                        }
                     }
                   })
                        .show();

            }
        });
















    }
    protected void restart()
    {
        onResume();
    }
    @Override
    protected void onResume() {
        super.onResume();
    }
    @Override
    protected void onRestart() {
        super.onRestart();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_details, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO Auto-generated method stub

        switch (item.getItemId()) {
            case R.id.menu_nieprzeczytane:
                Intent przejscieDoNiePrzeczytanych = new Intent(wypozyczone.this, Nieprzeczytane.class);
                startActivity(przejscieDoNiePrzeczytanych);
                return true;
            case R.id.menu_przeczytane:
                 Intent przeczytane = new Intent(wypozyczone.this, Przeczytane.class);
                startActivity(przeczytane);
                return true;
            case R.id.menu_wtrakcie:
                Intent wTrakcie = new Intent(wypozyczone.this, wtrakcie.class);
                startActivity(wTrakcie);

                return true;
            case R.id.menu_wypozyczone:
                super.onRestart();
                return true;
            case R.id.menu_dodajksiazke:
                Intent dodaj_ksiazke = new Intent(wypozyczone.this, DodajKsiazke.class);
                startActivity(dodaj_ksiazke);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

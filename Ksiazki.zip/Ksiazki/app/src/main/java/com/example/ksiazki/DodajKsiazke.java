package com.example.ksiazki;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DodajKsiazke extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodajksiazke);

        EditText numer_strony = (EditText)findViewById(R.id.podaj_numer_strony);
        EditText tytul = (EditText)findViewById(R.id.podaj_tytul);
        EditText autor = (EditText)findViewById(R.id.podaj_autora);
        Button dodaj_ksiazke = (Button)findViewById(R.id.dodaj_ksiazke);
        TextView errors = (TextView)findViewById(R.id.errorsDodaj);

       numer_strony.setOnFocusChangeListener(new View.OnFocusChangeListener() {
           @Override
           public void onFocusChange(View v, boolean hasFocus) {
               if(TextUtils.isEmpty(numer_strony.getText().toString()))
               {
                   numer_strony.setError("NIE MOŻE BY PUSTY!");return;
               }
           }
       });

        tytul.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(TextUtils.isEmpty(tytul.getText().toString()))
                {
                    tytul.setError("NIE MOŻE BY PUSTY!");return;
                }
            }
        });


        autor.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(TextUtils.isEmpty(autor.getText().toString()))
                {
                    autor.setError("NIE MOŻE BY PUSTY!");return;
                }
            }
        });

        dodaj_ksiazke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String podany_tytul = tytul.getText().toString();
                String podany_autor = autor.getText().toString();
                String podany_numer_strony = numer_strony.getText().toString();
                Integer czy_przeczytano=6;
                RadioButton  czy_tak = (RadioButton)findViewById(R.id.czy_przeczytana_tak);
                RadioButton  czy_nie = (RadioButton)findViewById(R.id.czy_przeczytana_nie);
                String error = "";
                if(TextUtils.isEmpty(podany_autor))
                {
                    error += "PODAJ DANE AUTORA!\n";
                }
                if(TextUtils.isEmpty(podany_tytul))
                {
                    error += "PODAJ TYTUł!\n";
                }
                if(TextUtils.isEmpty(podany_numer_strony))
                {
                    error += "PODAJ NUMER STRONY!! Jeśli nie zacząłeś czytać wpisz 0!";
                }
                if(czy_tak.isChecked())
                {
                    czy_przeczytano = 1;
                }
                else if (czy_nie.isChecked())
                {
                    czy_przeczytano = 0;
                }
                else
                {
                    error += "Nie zaznaczono czy przeczytano!";
                }
                if(TextUtils.isEmpty(error))
                {

                  //  String Dane = "Autor: "+podany_autor+"\nTytuł: "+podany_tytul+"\nNumer strony: "+Integer.getInteger(podany_numer_strony)+podany_numer_strony+"\n czy przeczytano "+czy_przeczytano;
                 //   errors.setText(Dane);

                    DBHelper bazadanych = new DBHelper(DodajKsiazke.this);
                    bazadanych.dodajKsiazke(podany_tytul, podany_autor,podany_numer_strony,  czy_przeczytano);
                    Intent powrot = new Intent(DodajKsiazke.this, Nieprzeczytane.class);
                    startActivity(powrot);
                }
                else
                {
                    errors.setText(error);
                }
            }
        });

    }
}

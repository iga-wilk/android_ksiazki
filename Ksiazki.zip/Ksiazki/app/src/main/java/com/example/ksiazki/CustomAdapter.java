package com.example.ksiazki;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    Context context;
    String id_ksiazek[];
    String tytuly_ksiazkek[];
    String autor[];
    String nr_strony[];
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext, String[] id_ksiazek, String[] tytuly_ksiazkek,String[] autor, String[] nr_strony) {
        this.context = applicationContext;
        this.id_ksiazek = id_ksiazek;
        this.tytuly_ksiazkek = tytuly_ksiazkek;
        this.autor = autor;
        this.nr_strony = nr_strony;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount()
    {
        return id_ksiazek.length;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
     @Override
    public Object getItem(int i)
     {
         return null;
     }

     @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        view = inflter.inflate(R.layout.activity_listview, null);
        TextView id = (TextView) view.findViewById(R.id.list_id);
        TextView tytuly =(TextView) view.findViewById(R.id.list2_tytul);
        TextView autorzy = (TextView) view.findViewById(R.id.autor_list2);
        TextView nr_stron =(TextView) view.findViewById(R.id.dodatkowe_dane_list);
        if(id_ksiazek[i] != null) {
            id.setText(id_ksiazek[i]);
            tytuly.setText(tytuly_ksiazkek[i]);
            autorzy.setText(autor[i]);
            nr_stron.setText(nr_strony[i]);

        }
        else
        {
            view.setVisibility(View.INVISIBLE);
        }

        return view;

    }
}

package com.example.ksiazki;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Przeczytane extends AppCompatActivity implements View.OnClickListener{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_przeczytane);


        DBHelper bazadanych = new DBHelper(Przeczytane.this);
        Cursor dane = bazadanych.wyswietl_przeczytane();
        Integer zmienna_pomocnicza = -1;

        String nr_strony[] = new String[1000] ;
        String autor[]= new String[1000];
        String id_list[]= new String[1000];
        String tytulu_list[]= new String[1000];
        Integer czy_przeczytano[] = new Integer[1000];
        Integer ilosc = 0;
        ListView Listaksiazek = (ListView)findViewById(R.id.lista_przeczytane);
        while(dane.moveToNext())
        {
            zmienna_pomocnicza = 1;

            autor[ilosc] = dane.getString(2);
            nr_strony[ilosc] = dane.getString(3);
            id_list[ilosc] = dane.getString(0);
            tytulu_list[ilosc] = dane.getString(1);
            czy_przeczytano[ilosc] = dane.getInt(4);
            ilosc++;
        }
        if(zmienna_pomocnicza == 1)
        {

            ((TextView)findViewById(R.id.przeczytane_id)).setText("ID");
            ((TextView)findViewById(R.id.przeczytane_tytul)).setText("tytul_ksiazki");
            ((TextView)findViewById(R.id.przeczytane_autor)).setText("autor");
            ((TextView)findViewById(R.id.przeczytane_nr_strony)).setText("nr_strony");

            CustomAdapter customadapter = new CustomAdapter(getApplicationContext(), id_list, tytulu_list,autor,nr_strony);
            Listaksiazek.setAdapter(customadapter);
        }
        else
        {
            String tytuł = ((TextView) findViewById(R.id.tytul_przeczytane)).getText().toString();
            tytuł += " \nBRAK POZYCJI KSIĄŻKOWYCH";
            ((TextView) findViewById(R.id.tytul_przeczytane)).setText(tytuł);
        }


        Listaksiazek. setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String zmienne[] = {"oznacz jako nieprzeczytane","edytuj/zmien numer strony", "usun książkę", "wypożycz"};
                new AlertDialog.Builder(Przeczytane.this)
                        .setTitle("Wybierz opcję").setItems(zmienne,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        switch(which){
                            case 0: bazadanych.oznacz_przeczytane_nieprzeczytane(id_list[position],"1");
                                Intent odswiezenie = new Intent(Przeczytane.this, Przeczytane.class);
                                startActivity(odswiezenie);break;
                            case 1:
                                Intent intent = new Intent(Przeczytane.this,EdycjaKsiazki.class);
                                intent.putExtra("tytul",tytulu_list[position]);
                                intent.putExtra("autor",autor[position]);
                                intent.putExtra("numerstrony",nr_strony[position]);
                                intent.putExtra("id_ksiazki",id_list[position]);
                                intent.putExtra("czy_przeczytano",czy_przeczytano[position].toString());
                                intent.putExtra("strona","przeczytane");
                                startActivity(intent);break;
                            case 2:
                                bazadanych.usun_ksiazke(id_list[position]);
                                Intent odswiezenie2 = new Intent(Przeczytane.this, Przeczytane.class);
                                startActivity(odswiezenie2); break;
                            case 3:
                                int sprawdzenie = bazadanych.sprawdz_id(id_list[position]);
                                if( sprawdzenie == 0)
                                {
                                    Intent wypozyczenie = new Intent(Przeczytane.this,ZapisywanieWypozyczen.class);
                                    wypozyczenie.putExtra("id",id_list[position]);
                                    wypozyczenie.putExtra("tytul",tytulu_list[position]);
                                    startActivity(wypozyczenie);
                                }
                                else
                                {   String tytuł = ((TextView) findViewById(R.id.tytul_przeczytane)).getText().toString();
                                    tytuł += " \njuz wypożyczono tą pozycję";
                                    ((TextView) findViewById(R.id.tytul_przeczytane)).setText(tytuł);}break;
                            default: Toast.makeText(Przeczytane.this,"WYBRALES inne", Toast.LENGTH_LONG);
                        }
                    }
                })
                        .show();

            }
        });






    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_details, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO Auto-generated method stub

        switch (item.getItemId()) {
            case R.id.menu_nieprzeczytane:
                Intent przejscieDoPrzeczytanych = new Intent(Przeczytane.this, Nieprzeczytane.class);
                startActivity(przejscieDoPrzeczytanych);
                return true;
            case R.id.menu_przeczytane:
                super.onResume();
                return true;
            case R.id.menu_wtrakcie:
                Intent wTrakcie = new Intent(Przeczytane.this, wtrakcie.class);
                startActivity(wTrakcie);

                return true;
            case R.id.menu_wypozyczone:
                Intent wypozyczone = new Intent(Przeczytane.this, wypozyczone.class);
                startActivity(wypozyczone);
                return true;

            case R.id.menu_dodajksiazke:
                Intent dodaj_ksiazke = new Intent(Przeczytane.this, DodajKsiazke.class);
                startActivity(dodaj_ksiazke);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {

    }
}

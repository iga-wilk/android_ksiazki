package com.example.ksiazki;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;

public class AdapterWypozyczen extends BaseAdapter {

    Context context;
    String id_wypozyczenia[];
    String tytuly_ksiazkek[];
    String autor[];
    String dane[];
    String data[];
    LayoutInflater inflter;

    public AdapterWypozyczen(Context applicationContext, String[] id_wypozyczenia, String[] tytuly_ksiazkek,String[] autor, String[] dane, String[] data) {
        this.context = applicationContext;
        this.id_wypozyczenia = id_wypozyczenia;
        this.tytuly_ksiazkek = tytuly_ksiazkek;
        this.autor = autor;
        this.dane = dane;
        this.data = data;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount()
    {
        return id_wypozyczenia.length;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    @Override
    public Object getItem(int i)
    {
        return null;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup)
    {
        view = inflter.inflate(R.layout.activity_listview2, null);
       TextView id = (TextView) view.findViewById(R.id.list2_id);
        TextView tytuly =(TextView) view.findViewById(R.id.list2_tytul);
        TextView autorzy = (TextView) view.findViewById(R.id.autor_list2);
        TextView daneWypozyczenia =(TextView) view.findViewById(R.id.dodatkowe_dane_list);
        TextView daty =(TextView) view.findViewById(R.id.data_list2);


        id.setText(id_wypozyczenia[i]);
        tytuly.setText(tytuly_ksiazkek[i]);
        autorzy.setText(autor[i]);
        daneWypozyczenia.setText(dane[i]);
        daty.setText(data[i]);
        if (id_wypozyczenia[i] == null)
        {
            view.setVisibility(View.INVISIBLE);

        }
        return view;
        }



}

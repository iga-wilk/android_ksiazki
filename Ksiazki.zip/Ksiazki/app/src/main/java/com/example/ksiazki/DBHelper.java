package com.example.ksiazki;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public class DBHelper extends SQLiteOpenHelper {
    private final static int DB_VERSION = 1;
    private final static String DB_NAME = "Ksiazki.db";
    public DBHelper(Context context)
    {
        super (context, DB_NAME, null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL (
            "create table ksiazki ("
            + "_id integer primary key,"
            + " tytul VARCHAR(200), "
            + "autor VARCHAR (400), "
            + "nr_strony  Varchar(5),"
             + "czy_przeczytano INT)"
        );
        db.execSQL (
                "create table wypozyczono ("
                        + "wypozyczenie_id integer primary key,"
                        + " id_ksiazka INT, "
                        + "dane VARCHAR(400), "
                        + "Data_wypozyczenia DATE)"

        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    }
    // dodawanie nowej ksiazki
    public void dodajKsiazke(String tytul, String autor,String nr_strony, Integer czy_przeczytano)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues wartosci = new ContentValues();
        wartosci.put("tytul", tytul);
        wartosci.put("autor", autor);
        wartosci.put("nr_strony", nr_strony);
        wartosci.put("czy_przeczytano", czy_przeczytano);
        db.insert("ksiazki",null,wartosci);
    }

    public void dodajWypozyczenie(String id_ksiazka, String dane, String data)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues wartosci = new ContentValues();
        wartosci.put("id_ksiazka", id_ksiazka);
        wartosci.put("dane", dane);
        wartosci.put("Data_wypozyczenia", data);
        db.insert("wypozyczono",null,wartosci);
    }


    public Cursor wyswietl_wszystkie()
    {
        String[] colums = {"_id", "tytul", "autor", "nr_strony","czy_przeczytano"};
        SQLiteDatabase db = getReadableDatabase();
        Cursor kursor = db.query("ksiazki",colums,null,null,null,null,null);
        return kursor;
    }

    public Cursor wyswietl_nieprzeczytane()
    {
        String[] colums = {"_id", "tytul", "autor", "nr_strony","czy_przeczytano"};
        SQLiteDatabase db = getReadableDatabase();
        String where = "czy_przeczytano = 0";
        Cursor kursor = db.query("ksiazki",colums,where,null,null,null,null);
        return kursor;
    }

    public Cursor wyswietl_przeczytane()
    {
        String[] colums = {"_id", "tytul", "autor", "nr_strony","czy_przeczytano"};
        SQLiteDatabase db = getReadableDatabase();
        String where = "czy_przeczytano = 1";
        Cursor kursor = db.query("ksiazki",colums,where,null,null,null,null);
        return kursor;
    }
    public Cursor wyswietl_w_trakcie()
    {
        String[] colums = {"_id", "tytul", "autor", "nr_strony","czy_przeczytano"};
        SQLiteDatabase db = getReadableDatabase();
        String where = "nr_strony > 0 and czy_przeczytano = 0";
        Cursor kursor = db.query("ksiazki",colums,where,null,null,null,null);
        return kursor;
    }

    public Cursor wyswietl_wypozyczone()
    {
        SQLiteDatabase db = getReadableDatabase();
        String Rawquery = "Select wypozyczenie_id, id_ksiazka, tytul, autor, nr_strony, dane, Data_wypozyczenia from wypozyczono INNER JOIN ksiazki ON _id = id_ksiazka";
        Cursor kursor = db.rawQuery(Rawquery,null);
        return kursor;
    }

    public int sprawdz_id(String id)
    {
        String[] colums = {"id_ksiazka"};
        SQLiteDatabase db = getReadableDatabase();
        String Rawquery = "Select id_ksiazka from wypozyczono where id_ksiazka = "+id;
        Cursor kursor = db.rawQuery(Rawquery,null);
        while(kursor.moveToNext())
        {
            return 1;
        }
            return 0;

    }

    public void oznacz_przeczytane_nieprzeczytane(String id, String aktualny_status)
    {
        if(aktualny_status.equals("0"))  //nieprzeczytany
        {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues wartosci = new ContentValues();
            wartosci.put("czy_przeczytano",1);
            String where = "_id = "+id;
            db.update("ksiazki",wartosci,where,null);
        }
        else if (aktualny_status.equals("1"))
        {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues wartosci = new ContentValues();
            wartosci.put("czy_przeczytano",0);
            String where = "_id = "+id;
            db.update("ksiazki",wartosci,where,null);
        }
    }
    //edycja danych książki
    public void Edytuj_dane(String id, String tytul, String autor,String nr_strony, Integer czy_przeczytano)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues wartosci = new ContentValues();
        wartosci.put("tytul", tytul);
        wartosci.put("autor", autor);
        wartosci.put("nr_strony", nr_strony);
        wartosci.put("czy_przeczytano", czy_przeczytano);
        String where = "_id = "+id;
        db.update("ksiazki",wartosci,where,null);
    }

    //edycja danych wypozyczenia
    public void Edytuj_wypozyczenie(String id, String dane, String data)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues wartosci = new ContentValues();
        wartosci.put("dane", dane);
        wartosci.put("Data_wypozyczenia", data);
        String where = "wypozyczenie_id = "+id;
        db.update("wypozyczono",wartosci,where,null);
    }
    //usuń książkę
    public void usun_ksiazke(String id)
    {
        SQLiteDatabase db = getWritableDatabase();
        String where = "_id = "+id;
        db.delete("ksiazki",where,null);

    }

    public void usun_wypozyczenie(String id)
    {
        SQLiteDatabase db = getWritableDatabase();
        String where = "wypozyczenie_id = "+id;
        db.delete("wypozyczono",where,null);

    }
}

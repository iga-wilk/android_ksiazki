package com.example.ksiazki;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.KeyguardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.KeyStore;
import android.app.KeyguardManager;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;


import android.widget.TextView;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;

public class MainActivity extends AppCompatActivity {

    //Deklaracja zmiennych potrzebnych do identyfikacji odcisku palca
    private static final String KEY_NAME = "yourKey";
    private Cipher cipher;
    private KeyStore keyStore;
    private KeyGenerator keyGenerator;
    private TextView textView;
    private FingerprintManager.CryptoObject cryptoObject;
    private FingerprintManager fingerprintManager;
    private KeyguardManager keyguardManager;
    TextView tx1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //ustawienie aktywności
        tx1 = (TextView)findViewById(R.id.textView3);
        tx1.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {//Instancja KeyguardManager i FingerprintManager//
            keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
            textView = (TextView) findViewById(R.id.textview);

            if (!fingerprintManager.isHardwareDetected())//Sprawdzenie, czy telefon posiada czytnik linii papilarnych//
            {
                textView.setText("Twoje urzadzenie nie posiada czytnika linii papilarnych!");
            }

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED)  //Sprawdzenie czy użytkownik nadał uprawnienia aplikacji//
            {
                textView.setText("Nadaj uprawnienia!");
            }

            if (!fingerprintManager.hasEnrolledFingerprints()) // Sprawdzenie czy uzytkownik posiada dodany minimum jeden odcisk palca
            {
                textView.setText("Brak dodanego odcisku palca!");
            }

            if (!keyguardManager.isKeyguardSecure()) //Sprawdzenie czy blokada klawiatury jest zabezpieczona kodem PIN, wzorem lub hasłem, czy karta SIM jest obecnie zablokowana.
            {
                textView.setText("Włącz ustawienie blokady");
            }
            else
            {
                try
                {
                    generateKey(); //wywolanie metody
                }
                catch (FingerprintException e)
                {
                    e.printStackTrace();
                }

                if (initCipher()) //Sprawdzenie czy wywolana fukckcja zwróci "true"
                {
                    cryptoObject = new FingerprintManager.CryptoObject(cipher); // Utworzenie instancji typu CryptoObject
                    FingerprintHandler helper = new FingerprintHandler(this); // Utworzenie instancji klasy FingerprintHandler
                    helper.startAuth(fingerprintManager, cryptoObject); //wywołanie metody klasy FingerprintHandler do sprawdzenia poprawnego odcisku palca
                }
            }
        }
    }

    private void generateKey() throws FingerprintException //Stworzenie metody od generacji klucza
    {
        try
        {
            // Obtain a reference to the Keystore using the standard Android keystore container identifier (“AndroidKeystore”)//
            keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"); //Generowanie klucza
            keyStore.load(null); //Inicjacja pustego keystore
            keyGenerator.init(new //Inicjacja tajnego Generatora klucza
                    KeyGenParameterSpec.Builder(KEY_NAME, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    .setUserAuthenticationRequired(true).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7).build());
            keyGenerator.generateKey(); // Wygenerowanie klucza
        }
        catch (KeyStoreException | NoSuchAlgorithmException | NoSuchProviderException | InvalidAlgorithmParameterException | CertificateException | IOException exc) { exc.printStackTrace();
            throw new FingerprintException(exc);
        }
    }

    public boolean initCipher() { //metoda użyta do stworzenia szyfru
        try
        {
            cipher = Cipher.getInstance( //Uzyskanie instancji szyfru i konfiguracja przy użyciu właściwości wymaganych do uwierzytelnienia  linii papilarnych
                    KeyProperties.KEY_ALGORITHM_AES + "/" + KeyProperties.BLOCK_MODE_CBC + "/" + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException |
                NoSuchPaddingException e) {
            throw new RuntimeException("Failed to get Cipher", e);
        }

        try
        {
            keyStore.load(null);
            SecretKey key = (SecretKey) keyStore.getKey(KEY_NAME, null);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return true; // zwróc true jeśli inicjalizacja szyfru przeszła pomyślnie
        }
        catch (KeyPermanentlyInvalidatedException e)
        {
            return false;
        }
        catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException | NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("Failed to init Cipher", e);
        }
    }

    private class FingerprintException extends Exception {
        public FingerprintException(Exception e) {
            super(e);
        }
    }


}
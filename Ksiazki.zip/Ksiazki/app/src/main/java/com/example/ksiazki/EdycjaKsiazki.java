package com.example.ksiazki;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EdycjaKsiazki extends AppCompatActivity {
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edycja_ksiazki);
//       Dane wyslane z aktywnosci
        Intent intent = getIntent();
        String tytul = intent.getStringExtra("tytul");
        String autor = intent.getStringExtra("autor");
        String nr_strony = intent.getStringExtra("numerstrony");
        String id = intent.getStringExtra("id_ksiazki");
        String czy_przeczytano = intent.getStringExtra("czy_przeczytano");
        String strona = intent.getStringExtra("strona");

//        Przypisanie zmiennym pol z widoku
        EditText podaj_tytul = (EditText)findViewById(R.id.edycja_podaj_tytul);
        EditText podaj_autora = (EditText) findViewById(R.id.edycja_podaj_autor);
        EditText podaj_nr_strony = (EditText)findViewById(R.id.edycja_podaj_nr_strony);
        RadioButton tak = (RadioButton)findViewById(R.id.edycja_czy_przeczytałes_tak);
        RadioButton nie = (RadioButton)findViewById(R.id.edycja_czy_przeczytales_nie);
        TextView errors = (TextView) findViewById(R.id.edycja_errors);

//      Ustawienie podanych wartości w polach
        podaj_tytul.setText(tytul);
        podaj_autora.setText(autor);
        podaj_nr_strony.setText(nr_strony);
        if(czy_przeczytano.equals("0"))
        {
            nie.setChecked(true);
        }
        else
        {
            tak.setChecked(true);
        }

//     przypisanie zmiennym przyciskow z widoku
        Button zapisz_zmiany = (Button)findViewById(R.id.edycja_zapisz);


//      obsługa kliknięcia zapisz zmiany
        zapisz_zmiany.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            { // pobranie nowych wartosci
                String zmieniony_tytul = podaj_tytul.getText().toString();
                String zmieniony_autor = podaj_autora.getText().toString();
                String zmieniony_numer_strony = podaj_nr_strony.getText().toString();
                Integer czy_przeczytano = -1;
                String error ="";

//                Sprawdzenie radiogroup
                if(tak.isChecked())
                {
                    czy_przeczytano = 1;
                }
                else if (nie.isChecked())
                {
                    czy_przeczytano = 0;
                }
                else
                {
                    error += "Nie zaznaczono czy przeczytano!";
                }

//                Walidacja

                if(TextUtils.isEmpty(zmieniony_autor))
                {
                    error += "PODAJ DANE AUTORA!\n";
                }
                if(TextUtils.isEmpty(zmieniony_tytul))
                {
                    error += "PODAJ TYTUł!\n";
                }
                if(TextUtils.isEmpty(zmieniony_numer_strony))
                {
                    error += "PODAJ NUMER STRONY!! Jeśli nie zacząłeś czytać wpisz 0!";
                }

                if(TextUtils.isEmpty(error))
                {

                    DBHelper bazadanych = new DBHelper(EdycjaKsiazki.this);
                    bazadanych.Edytuj_dane(id, zmieniony_tytul,zmieniony_autor,zmieniony_numer_strony,czy_przeczytano);
                    switch(strona)
                    {
                        case "wtrakcie": Intent powrot_wtrakcie = new Intent(EdycjaKsiazki.this, wtrakcie.class);
                                        startActivity(powrot_wtrakcie);break;
                        case "przeczytane": Intent powrot_przeczytane = new Intent(EdycjaKsiazki.this, Przeczytane.class);
                                            startActivity(powrot_przeczytane);break;
                        case "nieprzeczytane":      Intent powrot = new Intent(EdycjaKsiazki.this, Nieprzeczytane.class);
                            startActivity(powrot);     break;
                        default:
                            Toast.makeText(EdycjaKsiazki.this,"nieistnieje",Toast.LENGTH_LONG);
                    }

                }
                else
                {
                    errors.setText(error);
                }
            }
        });








    }
}

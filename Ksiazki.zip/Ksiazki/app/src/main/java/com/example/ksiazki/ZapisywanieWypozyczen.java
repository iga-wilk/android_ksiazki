package com.example.ksiazki;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Date;

public class ZapisywanieWypozyczen extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formularz_wypozyczenia);
        Intent intent = getIntent();
        String tytul = intent.getStringExtra("tytul");
        String id = intent.getStringExtra("id");
        TextView tytul_ksiazki = (TextView)findViewById(R.id.formularz_wypozycz_tytul);
        tytul_ksiazki.setText(tytul);
        LocalDate  dateNow =  LocalDate.now();
// odczyt danych z pliku - walidacja obsługa "zapisz"
        Button zapiszdane = (Button) findViewById(R.id.formularz_wypozycz_zapisz);

        zapiszdane.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                String podajDane = ((EditText) findViewById(R.id.formularz_wypozycz_podaj_imie_nazwisko)).getText().toString();
                String podajDate = ((EditText) findViewById(R.id.formularz_wypozycz_podaj_date)).getText().toString();
                String error ="";

                if(TextUtils.isEmpty(podajDane))
                {
                    error += "PODAJ DANE OSOBY! \n";

                }
                if(TextUtils.isEmpty(podajDate))
                {
                    error +="PODAJ POPRAWNA DATA \n";
                }
                else
                {
                    try {

                        LocalDate sprawdz = LocalDate.parse(podajDate);
                        if(dateNow.isBefore(sprawdz))
                        {
                            error += "Data z przyszlosci";
                        }
                    } catch (DateTimeParseException e) {
                        error += "Zły format daty";
                    }
                }
                if(TextUtils.isEmpty(error))
                {
                 //   ((TextView)findViewById(R.id.formularz_wypozycz_errors)).setText(podajDane + " Data: "+ podajDate + dateNow.toString());
                    DBHelper bazadanych = new DBHelper(ZapisywanieWypozyczen.this);
                    bazadanych.dodajWypozyczenie(id, podajDane,podajDate);
                    Intent powrot = new Intent(ZapisywanieWypozyczen.this, wypozyczone.class);
                    startActivity(powrot);
                }

                else
                {
                    ((TextView)findViewById(R.id.formularz_wypozycz_errors)).setText(error);
                }
            }
        });

    }
}
